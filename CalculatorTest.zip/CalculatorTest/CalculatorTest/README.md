﻿### Generate Code Coverage
```
OpenCover.Console.exe -target:"C:\Users\zxtha\Documents\Visual Studio 2015\Projects\CalculatorTest\CalculatorTest\bin\Debug\CalculatorTest.exe" -output:"C:\Users\zxtha\Documents\Visual Studio 2015\Projects\CalculatorTest\CalculatorTest\bin\Debug\coverage.xml" -register:user
```

### Generate Code Coverage Report
```
ReportGenerator.exe -reports:"C:\Users\zxtha\Documents\Visual Studio 2015\Projects\CalculatorTest\CalculatorTest\bin\Debug\coverage.xml" -targetdir:"C:\Users\zxtha\Documents\Visual Studio 2015\Projects\CalculatorTest\CalculatorTest\bin\Debug\report" -sourcedirs:"C:\Users\zxtha\Documents\Visual Studio 2015\Projects\CalculatorTest\CalculatorTest\bin\Debug"
```