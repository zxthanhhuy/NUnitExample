﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorTest
{
    public class Calculator
    {
        public double Add(double firstNumber, double secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public double Subtract(double firstNumber, double secondNumber)
        {
            return firstNumber - secondNumber;
        }

        public double Multiply(double firstNumber, double secondNumber)
        {
            return firstNumber * secondNumber;
        }

        public double Divide(double firstNumber, double secondNumber)
        {
            return firstNumber / secondNumber;
        }

        public double Pow(double value, double power)
        {
            return Math.Pow(value, power);
        }

        public double CalculateFactorial(int value)
        {
            if (value == 0)
            {
                return 1;
            }

            int fact = 1;
            for (int temp = 2; temp <= value; temp++)
            {
                fact = fact * temp;
            }

            return fact;
        }
    }
}
