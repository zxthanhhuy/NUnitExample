﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator cal = new Calculator();
            cal.Divide(20, 0);
            //int a = 1;
            //int b = 0;
            //int x = a / b;

            Console.ReadKey();
        }
    }
}
