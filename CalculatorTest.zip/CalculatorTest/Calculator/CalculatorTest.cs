﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Calculator
{
    [TestFixture]
    public class CalculatorTest
    {
        private Calculator _cal;

        [SetUp]
        public void SetUp()
        {
            _cal = new Calculator();
        }


        [OneTimeTearDown]
        public void TearDown()
        {
            _cal = null;
        }

        [TestCase(10, 5, 15)]
        [TestCase(-10.53, -2, -12.53)]
        [TestCase(10, -1.25, 8.75)]
        [TestCase(0, 2, 2)]
        public void TestAddition(double firstNumber, double secondNumber, double result)
        {
            Assert.AreEqual(result, _cal.Add(firstNumber, secondNumber));
        }

        [TestCase(10.5, 5, 5.5)]
        [TestCase(10.25, 12, -1.75)]
        [TestCase(-10, -5, -5)]
        [TestCase(-5, -10, 5)]
        [TestCase(10.1, -5.63, 15.73)]
        [TestCase(-10.31, 6.35, -16.66)]
        public void TestSubtraction(double firstNumber, double secondNumber, double result)
        {
            Assert.AreEqual(result, _cal.Subtract(firstNumber, secondNumber));
        }

        [TestCase(2.5, 2, 5)]
        [TestCase(5, -2.5, -12.5)]
        [TestCase(-2.5, -3, 7.5)]
        [TestCase(3, 0, 0)]
        [TestCase(Double.PositiveInfinity, 2, Double.PositiveInfinity)]
        public void TestMultiplication(double firstNumber, double secondNumber, double result)
        {
            Assert.AreEqual(result, _cal.Multiply(firstNumber, secondNumber));
        }


        [TestCase(12.5, 5, 2.5)]
        //[TestCase(-10, 2.5, -4)]
        //[TestCase(-12, -3, 4)]
        //[TestCase(0, 25, 0)]
        //[TestCase(20, 0, Double.PositiveInfinity)]
        public void TestDivision(double firstNumber, double secondNumber, double result)
        {
            Assert.AreEqual(result, _cal.Divide(firstNumber, secondNumber));
        }

        //[Ignore, TestCase(20, 0)]
        //public void TestDivionByZero(double firstNumber, double secondNumber)
        //{
        //    Assert.That(() => _cal.Divide(firstNumber, secondNumber), Throws.TypeOf<ArgumentException>());
        //}

        [TestCase(2.5, 2, 6.25)]
        [TestCase(-6, 2, 36)]
        [TestCase(2.5, 3, 15.625)]
        [TestCase(-1.5, 3, -3.375)]
        [TestCase(1.5, 1.5, 1.8371173070873836)]
        [TestCase(0, 4, 0)]
        [TestCase(12, 0, 1)]
        public void TestPower(double value, double power, double result)
        {
            Assert.AreEqual(result, _cal.Pow(value, power));
        }

        [TestCase(0, 1)]
        [TestCase(1, 1)]
        [TestCase(2, 2)]
        [TestCase(3, 6)]
        public void TestFactorialCalculation(int value, int result)
        {
            Assert.AreEqual(result, _cal.CalculateFactorial(value));
        }
    }
}
